package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Complaint {
	@Id
private int complaintid;
private String emailid;
private String customername;
private String address;
private String typeofproblem;
private String concern;
private String Status;
public int getComplaintid() {
	return complaintid;
}
public void setComplaintid(int complaintid) {
	this.complaintid = complaintid;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getTypeofproblem() {
	return typeofproblem;
}
public void setTypeofproblem(String typeofproblem) {
	this.typeofproblem = typeofproblem;
}
public String getConcern() {
	return concern;
}
public void setConcern(String concern) {
	this.concern = concern;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
@Override
public String toString() {
	return "Complaint [complaintid=" + complaintid + ", emailid=" + emailid + ", customername=" + customername
			+ ", address=" + address + ", typeofproblem=" + typeofproblem + ", concern=" + concern + ", Status="
			+ Status + "]";
}


}
