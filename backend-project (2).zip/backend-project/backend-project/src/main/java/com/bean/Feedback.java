package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Feedback {
@Id
	private int fid;
	private int complaintid;
	private String feedback;
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public int getComplaintid() {
		return complaintid;
	}
	public void setComplaintid(int complaintid) {
		this.complaintid = complaintid;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	@Override
	public String toString() {
		return "Feedback [fid=" + fid + ", complaintid=" + complaintid + ", feedback=" + feedback + "]";
	}
	
	
}
