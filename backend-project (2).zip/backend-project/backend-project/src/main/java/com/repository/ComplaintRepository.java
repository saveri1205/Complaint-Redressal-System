package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bean.Complaint;


public interface ComplaintRepository extends JpaRepository<Complaint, String> {

}
 
