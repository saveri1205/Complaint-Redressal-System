package com.telecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com")
@EntityScan(basePackages = "com.crs.main.model")
@EnableJpaRepositories(basePackages = "com.crs.main.repository")
class MyApplicationTests {

	@Test
	void contextLoads() {
	}

}